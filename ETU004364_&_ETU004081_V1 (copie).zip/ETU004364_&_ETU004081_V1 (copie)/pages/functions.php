<?php
session_start();
require_once("../inc/connexion.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['motdepasse'])) {
    $email = mysqli_real_escape_string(dbconnect(), $_POST['email']);
    $motdepasse = mysqli_real_escape_string(dbconnect(), $_POST['motdepasse']);
    
    $user = verifyLogin($email, $motdepasse);
    if ($user) {
        $_SESSION['id_membre'] = $user['id_membre'];
        $_SESSION['Nom'] = $user['Nom'];
        header("Location: listes_objets.php?success=Connexion réussie");
        exit();
    } else {
        header("Location: Login.php?error=Email ou mot de passe incorrect");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['motdepasse'], $_POST['nom'], $_POST['datedenaissance'], $_POST['genre'], $_POST['ville'])) {
    $email = mysqli_real_escape_string(dbconnect(), $_POST['email']);
    $motdepasse = mysqli_real_escape_string(dbconnect(), $_POST['motdepasse']);
    $nom = mysqli_real_escape_string(dbconnect(), $_POST['nom']);
    $datedenaissance = mysqli_real_escape_string(dbconnect(), $_POST['datedenaissance']);
    $genre = mysqli_real_escape_string(dbconnect(), $_POST['genre']);
    $ville = mysqli_real_escape_string(dbconnect(), $_POST['ville']);
    
    $result = registerUser($email, $motdepasse, $nom, $datedenaissance, $genre, $ville);
    if ($result === true) {
        header("Location: Login.php?success=Inscription réussie, veuillez vous connecter");
        exit();
    } else {
        header("Location: index.php?error=" . urlencode($result));
        exit();
    }
}

function checkLogin()
{
    if (!isset($_SESSION['id_membre'])) {
        header("Location: Login.php");
        exit();
    }
}

function displayMessage()
{
    if (isset($_GET['error'])) {
        echo '<p class="error">' . ($_GET['error']) . '</p>';
    }
    if (isset($_GET['success'])) {
        echo '<p class="success">' . ($_GET['success']) . '</p>';
    }
}

function formatDate($datetime)
{
    $date = new DateTime($datetime);
    return $date->format('d F Y');
}

function getUserById($id_membre)
{
    $conn = dbconnect();
    if (!$conn) {
        error_log("Database connection failed: " . mysqli_connect_error());
        return null;
    }

    $id_membre = mysqli_real_escape_string($conn, $id_membre);
    $requete = "SELECT id_membre, Nom, Sary FROM Membres_indrana WHERE id_membre = '$id_membre'";
    $result = mysqli_query($conn, $requete);
    $user = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $user;
}

function registerUser($email, $motdepasse, $nom, $datedenaissance, $genre, $ville)
{
    $conn = dbconnect();
    if (!$conn) {
        return "Échec de la connexion à la base de données";
    }

    $email = mysqli_real_escape_string($conn, $email);
    $motdepasse = mysqli_real_escape_string($conn, $motdepasse);
    $nom = mysqli_real_escape_string($conn, $nom);
    $datedenaissance = mysqli_real_escape_string($conn, $datedenaissance);
    $genre = mysqli_real_escape_string($conn, $genre);
    $ville = mysqli_real_escape_string($conn, $ville);
    
    $requete = "INSERT INTO Membres_indrana (Nom, Date_de_naissance, Genre, Email, Ville, Mdp, Sary) 
                VALUES ('$nom', '$datedenaissance', '$genre', '$email', '$ville', '$motdepasse', NULL)";
    if (mysqli_query($conn, $requete)) {
        return true;
    } else {
        $error = "Erreur lors de l'inscription : " . mysqli_error($conn);
        return $error;
    }
}

function verifyLogin($email, $motdepasse)
{
    $conn = dbconnect();
    if (!$conn) {
        return "Échec de la connexion à la base de données";
    }

    $email = mysqli_real_escape_string($conn, $email);
    $motdepasse = mysqli_real_escape_string($conn, $motdepasse);
    $requete = "SELECT id_membre, Nom FROM Membres_indrana WHERE Email = '$email' AND Mdp = '$motdepasse'";
    $result = mysqli_query($conn, $requete);
    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        return $user;
    }
    mysqli_free_result($result);
    return false;
}

function get_objets()
{
    $conn = dbconnect();
    if (!$conn) {
        return [];
    }

    $requete = "SELECT objet_indrana.id_objet, objet_indrana.Nom_objet, categorie_objet_indrana.Nom_categorie, 
                       Membres_indrana.Nom AS Proprietaire, emprunt_indrana.Date_emprunt, emprunt_indrana.Date_retour,
                       image_objet_indrana.Nom_image
                FROM objet_indrana 
                JOIN categorie_objet_indrana ON objet_indrana.id_categorie = categorie_objet_indrana.id_categorie 
                JOIN Membres_indrana ON objet_indrana.id_membre = Membres_indrana.id_membre 
                LEFT JOIN emprunt_indrana ON objet_indrana.id_objet = emprunt_indrana.id_objet 
                AND emprunt_indrana.Date_emprunt = (
                    SELECT MAX(Date_emprunt)
                    FROM emprunt_indrana e2
                    WHERE e2.id_objet = objet_indrana.id_objet
                )
                LEFT JOIN image_objet_indrana ON objet_indrana.id_objet = image_objet_indrana.id_objet
                ORDER BY objet_indrana.Nom_objet";
    $result = mysqli_query($conn, $requete);
    $resultat = [];
    while ($donnee = mysqli_fetch_assoc($result)) {
        $resultat[] = $donnee;
    }
    mysqli_free_result($result);
    return $resultat;
}

function get_categories()
{
    $conn = dbconnect();
    if (!$conn) {
        return [];
    }

    $requete = "SELECT id_categorie, Nom_categorie FROM categorie_objet_indrana ORDER BY Nom_categorie";
    $result = mysqli_query($conn, $requete);
    $categories = [];
    while ($donnee = mysqli_fetch_assoc($result)) {
        $categories[] = $donnee;
    }
    mysqli_free_result($result);
    return $categories;
}

function get_objets_by_category($id_categorie)
{
    $conn = dbconnect();
    if (!$conn) {
        return [];
    }

    $id_categorie = mysqli_real_escape_string($conn, $id_categorie);
    $requete = "SELECT objet_indrana.id_objet, objet_indrana.Nom_objet, categorie_objet_indrana.Nom_categorie, 
                       Membres_indrana.Nom AS Proprietaire, emprunt_indrana.Date_emprunt, emprunt_indrana.Date_retour,
                       image_objet_indrana.Nom_image
                FROM objet_indrana 
                JOIN categorie_objet_indrana ON objet_indrana.id_categorie = categorie_objet_indrana.id_categorie 
                JOIN Membres_indrana ON objet_indrana.id_membre = Membres_indrana.id_membre 
                LEFT JOIN emprunt_indrana ON objet_indrana.id_objet = emprunt_indrana.id_objet 
                AND emprunt_indrana.Date_emprunt = (
                    SELECT MAX(Date_emprunt)
                    FROM emprunt_indrana e2
                    WHERE e2.id_objet = objet_indrana.id_objet
                )
                LEFT JOIN image_objet_indrana ON objet_indrana.id_objet = image_objet_indrana.id_objet
                WHERE objet_indrana.id_categorie = '$id_categorie'
                ORDER BY objet_indrana.Nom_objet";
    $result = mysqli_query($conn, $requete);
    $resultat = [];
    while ($donnee = mysqli_fetch_assoc($result)) {
        $resultat[] = $donnee;
    }
    mysqli_free_result($result);
    return $resultat;
}
?>