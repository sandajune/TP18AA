<?php
session_start();
require_once("functions.php");
checkLogin();

$categories = get_categories();
$objects = [];
$selected_category = isset($_GET['categorie']) ? $_GET['categorie'] : '';

if ($selected_category) {
    $objects = get_objets_by_category($selected_category);
} else {
    $objects = get_objets();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filtrer les Objets par Catégorie</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <main>
            <h1 class="mb-4">Filtrer les Objets</h1>
            <?php displayMessage(); ?>
            <form method="get" action="filter.php" class="mb-3">
                <div class="input-group">
                    <label for="categorie" class="form-label">Catégorie :</label>
                    <select id="categorie" name="categorie" class="form-select" onchange="this.form.submit()">
                        <option value="">Toutes les catégories</option>
                        <?php foreach ($categories as $category) { ?>
                            <option value="<?php echo htmlspecialchars($category['id_categorie']); ?>" 
                                <?php echo $selected_category == $category['id_categorie'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category['Nom_categorie']); ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </form>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nom de l'objet</th>
                        <th>Catégorie</th>
                        <th>Propriétaire</th>
                        <th>Date d'emprunt</th>
                        <th>Date de retour</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($objects as $object) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($object['Nom_objet']); ?></td>
                            <td><?php echo htmlspecialchars($object['Nom_categorie']); ?></td>
                            <td><?php echo htmlspecialchars($object['Proprietaire']); ?></td>
                            <td><?php echo $object['Date_emprunt'] ? formatDate($object['Date_emprunt']) : 'Non emprunté'; ?></td>
                            <td><?php echo $object['Date_retour'] ? formatDate($object['Date_retour']) : 'Non retourné'; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <p><a href="listes_objets.php" class="btn btn-primary">Voir tous les objets</a></p>
            <p><a href="Logout.php" class="btn btn-secondary">Se déconnecter</a></p>
        </main>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>