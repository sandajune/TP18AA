<?php
session_start();
require_once("functions.php");
checkLogin();
$objects = get_objets();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Objets</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <style>
        .image-cell img {
            max-width: 100px;
            max-height: 100px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <main>
            <h1 class="mb-4">Liste des Objets</h1>
            <?php displayMessage(); ?>
            <p><a href="filter.php" class="btn btn-primary mb-3">Filtrer par catégorie</a></p>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Nom de l'objet</th>
                        <th>Catégorie</th>
                        <th>Propriétaire</th>
                        <th>Date d'emprunt</th>
                        <th>Date de retour</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($objects as $object) { ?>
                        <tr>
                            <td class="image-cell">
                                <?php if ($object['Nom_image']) { ?>
                                    <img src="../assets/images/<?php echo htmlspecialchars($object['Nom_image']); ?>" alt="Image de <?php echo htmlspecialchars($object['Nom_objet']); ?>">
                                <?php } else { ?>
                                    <span>Aucune image</span>
                                <?php } ?>
                            </td>
                            <td><?php echo htmlspecialchars($object['Nom_objet']); ?></td>
                            <td><?php echo htmlspecialchars($object['Nom_categorie']); ?></td>
                            <td><?php echo htmlspecialchars($object['Proprietaire']); ?></td>
                            <td><?php echo $object['Date_emprunt'] ? formatDate($object['Date_emprunt']) : 'Non emprunté'; ?></td>
                            <td><?php echo $object['Date_retour'] ? formatDate($object['Date_retour']) : 'Non retourné'; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <p><a href="Logout.php" class="btn btn-secondary">Se déconnecter</a></p>
        </main>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>