<?php 
header("Location:pages/Login.php");
?>