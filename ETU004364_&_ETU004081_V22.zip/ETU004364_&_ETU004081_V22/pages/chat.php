```html
<?php
session_start();
require_once("functions.php");
checkLogin();
$objects = get_objets();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Objets</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <style>
        .card-img-top {
            max-width: 100px;
            max-height: 100px;
            border: 2px solid #ccc;
            border-radius: 5px;
        }
        .thumbnail {
            max-width: 50px;
            max-height: 50px;
            margin-right: 5px;
        }
        .card {
            margin-bottom: 20px;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .image-upload {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <main>
            <h1 class="mb-4 text-center">Liste des Objets</h1>
            <?php displayMessage(); ?>
            <p class="text-center"><a href="filter.php" class="btn btn-primary mb-3">Filtrer par catégorie</a></p>
            <div class="row">
                <?php foreach ($objects as $object) { ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <?php
                                $defaultImage = "../assets/images/default.jpg";
                                $images = get_images_by_object($object['id_objet']);
                                $principalImage = !empty($images) ? "../assets/images/" . htmlspecialchars($images[0]['Nom_image']) : $defaultImage;
                                ?>
                                <img src="<?php echo $principalImage; ?>" alt="Image de <?php echo htmlspecialchars($object['Nom_objet']); ?>" class="card-img-top mx-auto d-block">
                                <?php if (count($images) > 1) { ?>
                                    <div class="mt-2">Autres images: 
                                        <?php for ($i = 1; $i < min(count($images), 3); $i++) { ?>
                                            <img src="../assets/images/<?php echo htmlspecialchars($images[$i]['Nom_image']); ?>" alt="Image supplémentaire" class="thumbnail">
                                        <?php } ?>
                                    </div>
                                <?php } ?>
                                <h5 class="card-title mt-3"><?php echo htmlspecialchars($object['Nom_objet']); ?></h5>
                                <p class="card-text">
                                    <strong>Catégorie :</strong> <?php echo htmlspecialchars($object['Nom_categorie']); ?><br>
                                    <strong>Propriétaire :</strong> <?php echo htmlspecialchars($object['Proprietaire']); ?><br>
                                    <strong>Date d'emprunt :</strong> <?php echo $object['Date_emprunt'] ? formatDate($object['Date_emprunt']) : 'Non emprunté'; ?><br>
                                    <strong>Date de retour :</strong> <?php echo $object['Date_retour'] ? formatDate($object['Date_retour']) : 'Non retourné'; ?>
                                </p>
                                <a href="details.php?id=<?php echo $object['id_objet']; ?>" class="btn btn-info btn-sm mb-2">Détails</a>
                                <?php if ($object['id_membre'] == $_SESSION['id_membre']) { ?>
                                    <form method="post" action="" class="image-upload" enctype="multipart/form-data">
                                        <input type="file" name="nouvelle_image" accept="image/jpeg,image/png,image/gif" class="form-control form-control-sm mb-2">
                                        <input type="hidden" name="id_objet" value="<?php echo $object['id_objet']; ?>">
                                        <button type="submit" name="upload_image" class="btn btn-success btn-sm">Uploader</button>
                                    </form>
                                    <?php if (!empty($images)) { ?>
                                        <form method="post" action="">
                                            <input type="hidden" name="id_image" value="<?php echo $images[0]['id_image']; ?>">
                                            <button type="submit" name="supprimer_image" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer la suppression ?');">Supprimer</button>
                                        </form>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <p class="text-center"><a href="Logout.php" class="btn btn-secondary">Se déconnecter</a></p>
        </main>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['upload_image']) && isset($_FILES['nouvelle_image']) && isset($_POST['id_objet'])) {
        $id_objet = $_POST['id_objet'];
        $tmp_name = $_FILES['nouvelle_image']['tmp_name'];
        $nomOriginal = $_FILES['nouvelle_image']['name'];
        $nomFichier = uploaderImage($tmp_name, $nomOriginal);
        if ($nomFichier) {
            $conn = dbconnect();
            $nomFichier = mysqli_real_escape_string($conn, $nomFichier);
            $id_objet = mysqli_real_escape_string($conn, $id_objet);
            $requete = "INSERT INTO image_objet_indrana (id_objet, Nom_image) VALUES ('$id_objet', '$nomFichier')";
            mysqli_query($conn, $requete);
            header("Location: listes_objets.php?success=Image téléchargée avec succès");
            exit();
        }
    } elseif (isset($_POST['supprimer_image']) && isset($_POST['id_image'])) {
        $id_image = $_POST['id_image'];
        $conn = dbconnect();
        $id_image = mysqli_real_escape_string($conn, $id_image);
        $requete = "SELECT Nom_image FROM image_objet_indrana WHERE id_image = '$id_image'";
        $result = mysqli_query($conn, $requete);
        $image = mysqli_fetch_assoc($result);
        if ($image && supprimerImage("../assets/images/" . $image['Nom_image'])) {
            $requete = "DELETE FROM image_objet_indrana WHERE id_image = '$id_image'";
            mysqli_query($conn, $requete);
            header("Location: listes_objets.php?success=Image supprimée avec succès");
            exit();
        }
    }
}
?>
```

### Explications des Modifications :
1. **Passage à un design en cartes** :
   - Remplacement de la table par un conteneur `row` avec des colonnes `col-md-4` pour afficher les objets sous forme de cartes Bootstrap (`card`).
   - Chaque carte contient une image principale, des informations (nom, catégorie, propriétaire, dates), et les boutons d'action.

2. **Amélioration du design** :
   - Ajout de styles CSS pour les cartes (effet `hover` avec `scale`, bordures, espacement).
   - Centrage des éléments avec `text-center` et utilisation de classes Bootstrap pour une mise en page responsive.
   - L'image principale est centrée avec `mx-auto d-block`.

3. **Conservation des fonctionnalités** :
   - Gestion des images (principale, autres images en vignettes, image par défaut).
   - Upload et suppression d'images limités au propriétaire (`id_membre` vérifié).
   - Lien "Détails" et bouton de déconnexion.

### Remarques :
- Assurez-vous que `../assets/images/` existe avec une image `default.jpg` comme fallback.
- Le fichier `functions.php` reste inchangé par rapport à la version précédente, car les fonctions (`get_images_by_object`, `uploaderImage`, `supprimerImage`, `get_objets`) sont déjà adaptées.
- Créez `details.php` si vous souhaitez une page détaillée.

Cette mise à jour améliore le design avec un affichage en cartes tout en respectant les autres exigences.