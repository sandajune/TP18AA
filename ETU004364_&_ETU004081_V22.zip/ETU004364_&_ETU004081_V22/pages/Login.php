
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <main class="col-md-6 offset-md-3">
            <h1 class="mb-4">Connexion</h1>
            <?php if (isset($_GET['error'])) { ?>
                <p class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php } ?>
            <?php if (isset($_GET['success'])) { ?>
                <p class="alert alert-success"><?php echo htmlspecialchars($_GET['success']); ?></p>
            <?php } ?>
            <form action="functions.php" method="post" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="email" class="form-label">Email :</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="motdepasse" class="form-label">Mot de passe :</label>
                    <input type="password" id="motdepasse" name="motdepasse" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">Se connecter</button>
            </form>
            <p class="mt-3">Pas de compte ? <a href="index.php" class="link-primary">Inscrivez-vous</a></p>
        </main>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>