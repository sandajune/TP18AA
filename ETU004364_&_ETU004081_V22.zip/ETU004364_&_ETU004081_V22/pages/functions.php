<?php
require_once("../inc/connexion.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['motdepasse'])) {
    $email = mysqli_real_escape_string(dbconnect(), $_POST['email']);
    $motdepasse = mysqli_real_escape_string(dbconnect(), $_POST['motdepasse']);
    
    $user = verifyLogin($email, $motdepasse);
    if ($user) {
        $_SESSION['id_membre'] = $user['id_membre'];
        $_SESSION['Nom'] = $user['Nom'];
        header("Location: listes_objets.php?success=Connexion réussie");
        exit();
    } else {
        header("Location: Login.php?error=Email ou mot de passe incorrect");
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'], $_POST['motdepasse'], $_POST['nom'], $_POST['datedenaissance'], $_POST['genre'], $_POST['ville'])) {
    $email = mysqli_real_escape_string(dbconnect(), $_POST['email']);
    $motdepasse = mysqli_real_escape_string(dbconnect(), $_POST['motdepasse']);
    $nom = mysqli_real_escape_string(dbconnect(), $_POST['nom']);
    $datedenaissance = mysqli_real_escape_string(dbconnect(), $_POST['datedenaissance']);
    $genre = mysqli_real_escape_string(dbconnect(), $_POST['genre']);
    $ville = mysqli_real_escape_string(dbconnect(), $_POST['ville']);
    
    $result = registerUser($email, $motdepasse, $nom, $datedenaissance, $genre, $ville);
    if ($result === true) {
        header("Location: Login.php?success=Inscription réussie, veuillez vous connecter");
        exit();
    } else {
        header("Location: index.php?error=" . urlencode($result));
        exit();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['upload_image']) && isset($_FILES['nouvelle_image']) && isset($_POST['id_objet'])) {
        $id_objet = $_POST['id_objet'];
        $tmp_name = $_FILES['nouvelle_image']['tmp_name'];
        $nomOriginal = $_FILES['nouvelle_image']['name'];
        $nomFichier = uploaderImage($tmp_name, $nomOriginal);
        if ($nomFichier) {
            $conn = dbconnect();
            $nomFichier = mysqli_real_escape_string($conn, $nomFichier);
            $id_objet = mysqli_real_escape_string($conn, $id_objet);
            $requete = "INSERT INTO image_objet_indrana (id_objet, Nom_image) VALUES ('$id_objet', '$nomFichier')";
            mysqli_query($conn, $requete);
            header("Location: listes_objets.php?success=Image téléchargée avec succès");
            exit();
        }
    } elseif (isset($_POST['supprimer_image']) && isset($_POST['id_image'])) {
        $id_image = $_POST['id_image'];
        $conn = dbconnect();
        $id_image = mysqli_real_escape_string($conn, $id_image);
        $requete = "SELECT Nom_image FROM image_objet_indrana WHERE id_image = '$id_image'";
        $result = mysqli_query($conn, $requete);
        $image = mysqli_fetch_assoc($result);
        if ($image && supprimerImage("../assets/images/" . $image['Nom_image'])) {
            $requete = "DELETE FROM image_objet_indrana WHERE id_image = '$id_image'";
            mysqli_query($conn, $requete);
            header("Location: listes_objets.php?success=Image supprimée avec succès");
            exit();
        }
    } elseif (isset($_POST['add_object']) && isset($_POST['nom_objet']) && isset($_POST['id_categorie'])) {
        $nom_objet = mysqli_real_escape_string(dbconnect(), $_POST['nom_objet']);
        $id_categorie = mysqli_real_escape_string(dbconnect(), $_POST['id_categorie']);
        $id_membre = $_SESSION['id_membre'];
        $conn = dbconnect();
        $requete = "INSERT INTO objet_indrana (Nom_objet, id_categorie, id_membre) VALUES ('$nom_objet', '$id_categorie', '$id_membre')";
        if (mysqli_query($conn, $requete)) {
            header("Location: listes_objets.php?success=Objet ajouté avec succès");
        } else {
            header("Location: listes_objets.php?error=Échec de l'ajout de l'objet");
        }
        exit();
    }
}

function checkLogin()
{
    if (!isset($_SESSION['id_membre'])) {
        header("Location: Login.php");
        exit();
    }
}

function displayMessage()
{
    if (isset($_GET['error'])) {
        echo '<p class="alert alert-danger">' . htmlspecialchars($_GET['error']) . '</p>';
    }
    if (isset($_GET['success'])) {
        echo '<p class="alert alert-success">' . htmlspecialchars($_GET['success']) . '</p>';
    }
}

function formatDate($datetime)
{
    $date = new DateTime($datetime);
    return $date->format('d F Y');
}

function getUserById($id_membre)
{
    $conn = dbconnect();
    if (!$conn) {
        error_log("Database connection failed: " . mysqli_connect_error());
        return null;
    }

    $id_membre = mysqli_real_escape_string($conn, $id_membre);
    $requete = "SELECT id_membre, Nom, Sary FROM Membres_indrana WHERE id_membre = '$id_membre'";
    $result = mysqli_query($conn, $requete);
    $user = mysqli_fetch_assoc($result);
    mysqli_free_result($result);
    return $user;
}

function registerUser($email, $motdepasse, $nom, $datedenaissance, $genre, $ville)
{
    $conn = dbconnect();
    if (!$conn) {
        return "Échec de la connexion à la base de données";
    }

    $email = mysqli_real_escape_string($conn, $email);
    $motdepasse = mysqli_real_escape_string($conn, $motdepasse);
    $nom = mysqli_real_escape_string($conn, $nom);
    $datedenaissance = mysqli_real_escape_string($conn, $datedenaissance);
    $genre = mysqli_real_escape_string($conn, $genre);
    $ville = mysqli_real_escape_string($conn, $ville);
    
    $requete = "INSERT INTO Membres_indrana (Nom, Date_de_naissance, Genre, Email, Ville, Mdp, Sary) 
                VALUES ('$nom', '$datedenaissance', '$genre', '$email', '$ville', '$motdepasse', NULL)";
    if (mysqli_query($conn, $requete)) {
        return true;
    } else {
        $error = "Erreur lors de l'inscription : " . mysqli_error($conn);
        return $error;
    }
}

function verifyLogin($email, $motdepasse)
{
    $conn = dbconnect();
    if (!$conn) {
        return "Échec de la connexion à la base de données";
    }

    $email = mysqli_real_escape_string($conn, $email);
    $motdepasse = mysqli_real_escape_string($conn, $motdepasse);
    $requete = "SELECT id_membre, Nom FROM Membres_indrana WHERE Email = '$email' AND Mdp = '$motdepasse'";
    $result = mysqli_query($conn, $requete);
    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        mysqli_free_result($result);
        return $user;
    }
    mysqli_free_result($result);
    return false;
}

function get_objets() {
    $conn = dbconnect();
    if (!$conn) return [];
    $requete = "SELECT o.id_objet, o.Nom_objet, c.Nom_categorie, m.Nom AS Proprietaire, 
                       e.Date_emprunt, e.Date_retour, o.id_membre
                FROM objet_indrana o
                JOIN categorie_objet_indrana c ON o.id_categorie = c.id_categorie
                JOIN Membres_indrana m ON o.id_membre = m.id_membre
                LEFT JOIN emprunt_indrana e ON o.id_objet = e.id_objet
                AND e.Date_emprunt = (
                    SELECT MAX(Date_emprunt)
                    FROM emprunt_indrana e2
                    WHERE e2.id_objet = o.id_objet
                )
                ORDER BY o.Nom_objet";
    $result = mysqli_query($conn, $requete);
    $resultat = [];
    while ($donnee = mysqli_fetch_assoc($result)) {
        $resultat[] = $donnee;
    }
    mysqli_free_result($result);
    return $resultat;
}

function get_categories()
{
    $conn = dbconnect();
    if (!$conn) {
        return [];
    }

    $requete = "SELECT id_categorie, Nom_categorie FROM categorie_objet_indrana ORDER BY Nom_categorie";
    $result = mysqli_query($conn, $requete);
    $categories = [];
    while ($donnee = mysqli_fetch_assoc($result)) {
        $categories[] = $donnee;
    }
    mysqli_free_result($result);
    return $categories;
}

function get_objets_by_category($id_categorie)
{
    $conn = dbconnect();
    if (!$conn) {
        return [];
    }

    $id_categorie = mysqli_real_escape_string($conn, $id_categorie);
    $requete = "SELECT o.id_objet, o.Nom_objet, c.Nom_categorie, m.Nom AS Proprietaire, 
                       e.Date_emprunt, e.Date_retour, o.id_membre
                FROM objet_indrana o
                JOIN categorie_objet_indrana c ON o.id_categorie = c.id_categorie
                JOIN Membres_indrana m ON o.id_membre = m.id_membre
                LEFT JOIN emprunt_indrana e ON o.id_objet = e.id_objet
                AND e.Date_emprunt = (
                    SELECT MAX(Date_emprunt)
                    FROM emprunt_indrana e2
                    WHERE e2.id_objet = o.id_objet
                )
                WHERE o.id_categorie = '$id_categorie'
                ORDER BY o.Nom_objet";
    $result = mysqli_query($conn, $requete);
    $resultat = [];
    while ($donnee = mysqli_fetch_assoc($result)) {
        $resultat[] = $donnee;
    }
    mysqli_free_result($result);
    return $resultat;
}

function get_images_by_object($id_objet) {
    $conn = dbconnect();
    if (!$conn) return [];
    $id_objet = mysqli_real_escape_string($conn, $id_objet);
    $requete = "SELECT id_image, Nom_image FROM image_objet_indrana WHERE id_objet = '$id_objet'";
    $result = mysqli_query($conn, $requete);
    $images = [];
    while ($donnee = mysqli_fetch_assoc($result)) {
        $images[] = $donnee;
    }
    mysqli_free_result($result);
    return $images;
}

function uploaderImage($tmp_name, $nomOriginal) {
    $pseudo = $_SESSION['Nom']; // Utilisation de Nom comme approximation
    if (!$pseudo || !is_uploaded_file($tmp_name)) {
        error_log("Error: Invalid pseudo or file not uploaded.");
        return false;
    }

    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $fileType = mime_content_type($tmp_name);
    if (!in_array($fileType, $allowedTypes)) {
        error_log("Error: Invalid file type: $fileType");
        return false;
    }

    if (filesize($tmp_name) > 5 * 1024 * 1024) {
        error_log("Error: File too large: " . filesize($tmp_name));
        return false;
    }

    $imageDir = "../assets/images/";
    if (!is_dir($imageDir)) {
        if (!mkdir($imageDir, 0755, true)) {
            error_log("Error: Failed to create directory: $imageDir");
            return false;
        }
    }

    $cleanName = preg_replace('/[^A-Za-z0-9\-\_\.]/', '_', basename($nomOriginal));
    $baseName = $pseudo . '_' . date('Ymd-His') . '_' . uniqid() . '_' . $cleanName;
    $nomFichier = $baseName;
    $destination = $imageDir . $nomFichier;
    $counter = 1;

    while (file_exists($destination)) {
        $nomFichier = $baseName . '_' . $counter;
        $destination = $imageDir . $nomFichier;
        $counter++;
    }

    if (move_uploaded_file($tmp_name, $destination)) {
        return $nomFichier;
    } else {
        error_log("Failed to move file from $tmp_name to $destination");
        return false;
    }
}

function supprimerImage($image) {
    if (file_exists($image)) {
        return unlink($image);
    }
    return false;
}

function get_default_image($category) {
    $defaults = [
        'Esthétiques' => '../assets/images/default1.jpeg',
        'Mécanique' => '../assets/images/default2.jpeg',
        'Bricolage' => '../assets/images/default3.jpeg',
        'Cuisine' => '../assets/images/default4.jpeg'
    ];
    return isset($defaults[$category]) ? $defaults[$category] : '../assets/images/default1.jpeg'; // Default fallback
}
?>