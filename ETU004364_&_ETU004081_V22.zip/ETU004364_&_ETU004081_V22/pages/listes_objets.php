<?php
session_start();
require_once("functions.php");
checkLogin();
$objects = get_objets();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['upload_image']) && isset($_FILES['nouvelle_image']) && isset($_POST['id_objet'])) {
        $id_objet = $_POST['id_objet'];
        $tmp_name = $_FILES['nouvelle_image']['tmp_name'];
        $nomOriginal = $_FILES['nouvelle_image']['name'];
        $nomFichier = uploaderImage($tmp_name, $nomOriginal);
        if ($nomFichier) {
            $conn = dbconnect();
            $nomFichier = mysqli_real_escape_string($conn, $nomFichier);
            $id_objet = mysqli_real_escape_string($conn, $id_objet);
            $requete = "INSERT INTO image_objet_indrana (id_objet, Nom_image) VALUES ('$id_objet', '$nomFichier')";
            mysqli_query($conn, $requete);
            header("Location: listes_objets.php?success=Image téléchargée avec succès");
            exit();
        }
    } elseif (isset($_POST['supprimer_image']) && isset($_POST['id_image'])) {
        $id_image = $_POST['id_image'];
        $conn = dbconnect();
        $id_image = mysqli_real_escape_string($conn, $id_image);
        $requete = "SELECT Nom_image FROM image_objet_indrana WHERE id_image = '$id_image'";
        $result = mysqli_query($conn, $requete);
        $image = mysqli_fetch_assoc($result);
        if ($image && supprimerImage("../assets/images/" . $image['Nom_image'])) {
            $requete = "DELETE FROM image_objet_indrana WHERE id_image = '$id_image'";
            mysqli_query($conn, $requete);
            header("Location: listes_objets.php?success=Image supprimée avec succès");
            exit();
        }
    } elseif (isset($_POST['add_object']) && isset($_POST['nom_objet']) && isset($_POST['id_categorie'])) {
        $nom_objet = mysqli_real_escape_string(dbconnect(), $_POST['nom_objet']);
        $id_categorie = mysqli_real_escape_string(dbconnect(), $_POST['id_categorie']);
        $id_membre = $_SESSION['id_membre'];
        $conn = dbconnect();
        $requete = "INSERT INTO objet_indrana (Nom_objet, id_categorie, id_membre) VALUES ('$nom_objet', '$id_categorie', '$id_membre')";
        if (mysqli_query($conn, $requete)) {
            header("Location: listes_objets.php?success=Objet ajouté avec succès");
        } else {
            header("Location: listes_objets.php?error=Échec de l'ajout de l'objet");
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des Objets</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <style>
        .card-img-top {
            max-width: 100px;
            max-height: 100px;
            border: 2px solid #ccc;
            border-radius: 5px;
        }
        .thumbnail {
            max-width: 50px;
            max-height: 50px;
            margin-right: 5px;
        }
        .card {
            margin-bottom: 20px;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.02);
        }
        .image-upload {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <main>
            <h1 class="mb-4 text-center">Liste des Objets</h1>
            <?php displayMessage(); ?>
            <p class="text-center"><a href="filter.php" class="btn btn-primary mb-3">Filtrer par catégorie</a></p>

            <!-- Formulaire pour ajouter un nouvel objet -->
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title">Ajouter un nouvel objet</h5>
                    <form method="post" action="">
                        <div class="mb-3">
                            <label for="nom_objet" class="form-label">Nom de l'objet :</label>
                            <input type="text" name="nom_objet" id="nom_objet" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="id_categorie" class="form-label">Catégorie :</label>
                            <select name="id_categorie" id="id_categorie" class="form-select" required>
                                <option value="">Sélectionner une catégorie</option>
                                <?php
                                $categories = get_categories();
                                foreach ($categories as $category) {
                                    echo "<option value='" . htmlspecialchars($category['id_categorie']) . "'>" . htmlspecialchars($category['Nom_categorie']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <button type="submit" name="add_object" class="btn btn-primary">Ajouter</button>
                    </form>
                </div>
            </div>

            <div class="row">
                <?php foreach ($objects as $object) { ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <?php
                                $defaultImage = get_default_image($object['Nom_categorie']);
                                $images = get_images_by_object($object['id_objet']);
                                $principalImage = !empty($images) ? "../assets/images/" . htmlspecialchars($images[0]['Nom_image']) : $defaultImage;
                                ?>
                                <img src="<?php echo $principalImage; ?>" alt="Image de <?php echo htmlspecialchars($object['Nom_objet']); ?>" class="card-img-top mx-auto d-block">
                                <?php if (count($images) > 1) { ?>
                                    <div class="mt-2">Autres images: 
                                        <?php for ($i = 1; $i < min(count($images), 3); $i++) { ?>
                                            <img src="../assets/images/<?php echo htmlspecialchars($images[$i]['Nom_image']); ?>" alt="Image supplémentaire" class="thumbnail">
                                        <?php } ?>
                                    </div>
                                <?php } ?>
                                <h5 class="card-title mt-3"><?php echo htmlspecialchars($object['Nom_objet']); ?></h5>
                                <p class="card-text">
                                    <strong>Catégorie :</strong> <?php echo htmlspecialchars($object['Nom_categorie']); ?><br>
                                    <strong>Propriétaire :</strong> <?php echo htmlspecialchars($object['Proprietaire']); ?><br>
                                    <strong>Date d'emprunt :</strong> <?php echo $object['Date_emprunt'] ? formatDate($object['Date_emprunt']) : 'Non emprunté'; ?><br>
                                    <strong>Date de retour :</strong> <?php echo $object['Date_retour'] ? formatDate($object['Date_retour']) : 'Non retourné'; ?>
                                </p>
                                <a href="details.php?id=<?php echo $object['id_objet']; ?>" class="btn btn-info btn-sm mb-2">Détails</a>
                                <?php if ($object['id_membre'] == $_SESSION['id_membre']) { ?>
                                    <form method="post" action="" class="image-upload" enctype="multipart/form-data">
                                        <input type="file" name="nouvelle_image" accept="image/jpeg,image/png,image/gif" class="form-control form-control-sm mb-2">
                                        <input type="hidden" name="id_objet" value="<?php echo $object['id_objet']; ?>">
                                        <button type="submit" name="upload_image" class="btn btn-success btn-sm">Uploader</button>
                                    </form>
                                    <?php if (!empty($images)) { ?>
                                        <form method="post" action="">
                                            <input type="hidden" name="id_image" value="<?php echo $images[0]['id_image']; ?>">
                                            <button type="submit" name="supprimer_image" class="btn btn-danger btn-sm" onclick="return confirm('Confirmer la suppression ?');">Supprimer</button>
                                        </form>
                                    <?php } ?>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <p class="text-center"><a href="Logout.php" class="btn btn-secondary">Se déconnecter</a></p>
        </main>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>