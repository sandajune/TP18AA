<?php
session_start();
require_once("functions.php");
checkLogin();

$categories = get_categories();
$objects = [];
$selected_category = isset($_GET['categorie']) ? $_GET['categorie'] : '';

if ($selected_category) {
    $objects = get_objets_by_category($selected_category);
} else {
    $objects = get_objets();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filtrer les Objets par Catégorie</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <style>
        .card-img-top {
            max-width: 100px;
            max-height: 100px;
            border: 2px solid #ccc;
            border-radius: 5px;
        }
        .thumbnail {
            max-width: 50px;
            max-height: 50px;
            margin-right: 5px;
        }
        .card {
            margin-bottom: 20px;
            transition: transform 0.2s;
        }
        .card:hover {
            transform: scale(1.02);
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <main>
            <h1 class="mb-4 text-center">Filtrer les Objets</h1>
            <?php displayMessage(); ?>
            <form method="get" action="filter.php" class="mb-3 text-center">
                <div class="input-group w-50 mx-auto">
                    <label for="categorie" class="form-label me-2">Catégorie :</label>
                    <select id="categorie" name="categorie" class="form-select" onchange="this.form.submit()">
                        <option value="">Toutes les catégories</option>
                        <?php foreach ($categories as $category) { ?>
                            <option value="<?php echo htmlspecialchars($category['id_categorie']); ?>" 
                                <?php echo $selected_category == $category['id_categorie'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($category['Nom_categorie']); ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </form>
            <div class="row">
                <?php foreach ($objects as $object) { ?>
                    <div class="col-md-4">
                        <div class="card">
                            <div class="card-body">
                                <?php
                                $defaultImage = get_default_image($object['Nom_categorie']);
                                $images = get_images_by_object($object['id_objet']);
                                $principalImage = !empty($images) ? "../assets/images/" . htmlspecialchars($images[0]['Nom_image']) : $defaultImage;
                                ?>
                                <img src="<?php echo $principalImage; ?>" alt="Image de <?php echo htmlspecialchars($object['Nom_objet']); ?>" class="card-img-top mx-auto d-block">
                                <?php if (count($images) > 1) { ?>
                                    <div class="mt-2">Autres images: 
                                        <?php for ($i = 1; $i < min(count($images), 3); $i++) { ?>
                                            <img src="../assets/images/<?php echo htmlspecialchars($images[$i]['Nom_image']); ?>" alt="Image supplémentaire" class="thumbnail">
                                        <?php } ?>
                                    </div>
                                <?php } ?>
                                <h5 class="card-title mt-3"><?php echo htmlspecialchars($object['Nom_objet']); ?></h5>
                                <p class="card-text">
                                    <strong>Catégorie :</strong> <?php echo htmlspecialchars($object['Nom_categorie']); ?><br>
                                    <strong>Propriétaire :</strong> <?php echo htmlspecialchars($object['Proprietaire']); ?><br>
                                    <strong>Date d'emprunt :</strong> <?php echo $object['Date_emprunt'] ? formatDate($object['Date_emprunt']) : 'Non emprunté'; ?><br>
                                    <strong>Date de retour :</strong> <?php echo $object['Date_retour'] ? formatDate($object['Date_retour']) : 'Non retourné'; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <p class="text-center"><a href="listes_objets.php" class="btn btn-primary">Voir tous les objets</a></p>
            <p class="text-center"><a href="Logout.php" class="btn btn-secondary">Se déconnecter</a></p>
        </main>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>