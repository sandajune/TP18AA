<?php
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <main class="col-md-6 offset-md-3">
            <h1 class="mb-4">Inscription</h1>
            <?php if (isset($_GET['error'])) { ?>
                <p class="alert alert-danger"><?php echo htmlspecialchars($_GET['error']); ?></p>
            <?php } ?>
            <form action="functions.php" method="post" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="email" class="form-label">Email :</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="motdepasse" class="form-label">Mot de passe :</label>
                    <input type="password" id="motdepasse" name="motdepasse" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="nom" class="form-label">Nom :</label>
                    <input type="text" id="nom" name="nom" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="datedenaissance" class="form-label">Date de naissance :</label>
                    <input type="date" id="datedenaissance" name="datedenaissance" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="genre" class="form-label">Genre :</label>
                    <select id="genre" name="genre" class="form-select" required>
                        <option value="Homme">Homme</option>
                        <option value="Femme">Femme</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="ville" class="form-label">Ville :</label>
                    <input type="text" id="ville" name="ville" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary">S'inscrire</button>
            </form>
            <p class="mt-3">Déjà un compte ? <a href="Login.php" class="link-primary">Connectez-vous</a></p>
        </main>
    </div>
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>
</body>
</html>