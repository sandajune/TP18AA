create database indrana;
use indrana;
create table Membres_indrana(
id_membre int  primary key AUTO_INCREMENT,
Nom VARCHAR(100),
Date_de_naissance DATE,
Genre VARCHAR(20),
Email VARCHAR(100) ,
Ville VARCHAR(100),
Mdp VARCHAR(100),
Sary VARCHAR(100)
);

create table categorie_objet_indrana(
id_categorie int primary key AUTO_INCREMENT,
Nom_categorie VARCHAR(100)
);

create table objet_indrana(
id_objet int primary key AUTO_INCREMENT,
Nom_objet VARCHAR(100),
id_categorie int,
id_membre int,
foreign key (id_categorie) references categorie_objet_indrana(id_categorie),
foreign key (id_membre) references Membres_indrana(id_membre)
);

create table image_objet_indrana(
id_image int primary key AUTO_INCREMENT,
id_objet int,
Nom_image VARCHAR(100),
foreign key (id_objet) references objet_indrana(id_objet)
);

create table emprunt_indrana(
    id_emprunt int primary key AUTO_INCREMENT,
    id_objet int,
    id_membre int,
    Date_emprunt DATE,
    Date_retour DATE,
    foreign key (id_objet) references objet_indrana(id_objet),
    foreign key (id_membre) references Membres_indrana(id_membre)
);

insert into Membres_indrana (Nom, Date_de_naissance, Genre, Email, Ville, Mdp, Sary) values
('Indrana', '1990-01-01', 'Femme', 'indrana@gmail.com', 'Antananarivo', '123456', '1.jpg'),
('Indra', '1990-01-01', 'Femme', 'indra@gmail.com', 'Antananarivo', '123', '2.jpg'),
('Maria', '1990-01-01', 'Femme', 'maria@gmail.com', 'Antananarivo', '456', '3.jpg'),
('Ilo', '1990-01-01', 'Homme', 'ilo@gmail.com', 'Antananarivo', '789', '4.jpg');

insert into categorie_objet_indrana (Nom_categorie) values
('Esthetiques'),
('Bricolage'),
('Mecanique'),
('Cuisine');

INSERT INTO objet_indrana (Nom_objet, id_categorie, id_membre) VALUES
('Pinceau_1', 1, 1), ('Miroir_1', 1, 1), ('Parfum_1', 1, 1), 
('Marteau_1', 2, 1), ('Tournevis_1', 2, 1), ('Scie_1', 2, 1), 
('Clé_1', 3, 1), ('Piston_1', 3, 1), 
('Casserole_1', 4, 1), ('Poêle_1', 4, 1), 

('Pinceau_2', 1, 2), ('Miroir_2', 1, 2), ('Parfum_2', 1, 2), 
('Marteau_2', 2, 2), ('Tournevis_2', 2, 2), ('Scie_2', 2, 2), 
('Clé_2', 3, 2), ('Piston_2', 3, 2), 
('Casserole_2', 4, 2), ('Poêle_2', 4, 2), 

('Pinceau_3', 1, 3), ('Miroir_3', 1, 3), ('Parfum_3', 1, 3), 
('Marteau_3', 2, 3), ('Tournevis_3', 2, 3), ('Scie_3', 2, 3), 
('Clé_3', 3, 3), ('Piston_3', 3, 3), 
('Casserole_3', 4, 3), ('Poêle_3', 4, 3), 

('Pinceau_4', 1, 4), ('Miroir_4', 1, 4), ('Parfum_4', 1, 4), 
('Marteau_4', 2, 4), ('Tournevis_4', 2, 4), ('Scie_4', 2, 4), 
('Clé_4', 3, 4), ('Piston_4', 3, 4), 
('Casserole_4', 4, 4), ('Poêle_4', 4, 4); 


INSERT INTO emprunt_indrana (id_objet, id_membre, Date_emprunt, Date_retour) VALUES
(2, 1, '2025-06-01', '2025-06-08'), 
(15, 1, '2025-06-10', '2025-06-17'), 
(27, 1, '2025-07-01', NULL), 

(11, 2, '2025-06-05', '2025-06-12'), 
(25, 2, '2025-06-15', '2025-06-22'), 
(38, 2, '2025-07-05', NULL), 

(7, 3, '2025-06-20', '2025-06-27'), 
(20, 3, '2025-07-01', '2025-07-08'), 

(1, 4, '2025-06-25', '2025-07-02'), 
(34, 4, '2025-07-10', NULL); 